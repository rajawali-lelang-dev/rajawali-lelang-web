import React from 'react'
import Header from '@/components/layout/Header'

function AppLayout() {
  return (
    <Header></Header>
  )
}

export default AppLayout