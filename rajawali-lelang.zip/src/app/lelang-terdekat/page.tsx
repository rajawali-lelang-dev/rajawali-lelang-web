import { Metadata } from 'next'
import { FadeInUp } from '@/components/common/ScrollAnimation'
import Link from 'next/link'
import Image from 'next/image'

export const metadata: Metadata = {
  title: 'Jadwal Lelang Terdekat | Rajawali Lelang Indonesia',
  description: 'Jangan lewatkan kesempatan untuk mendapatkan properti impian Anda. Tandai kalender Anda!',
}

interface AuctionSchedule {
  id: string
  date: string
  time: string
  title: string
  location: string
  type: string
}

const upcomingAuctions: AuctionSchedule[] = [
  {
    id: '1',
    date: '25 Okt 2025',
    time: '10:00 WIB',
    title: 'Rumah Tinggal, Jakarta Utara',
    location: 'Jakarta Utara',
    type: 'Lelang Eksekusi Hak Tanggungan'
  },
  {
    id: '2',
    date: '12 Nov 2025',
    time: '14:00 WIB',
    title: 'Tanah Kavling, Bali',
    location: 'Bali',
    type: 'Lelang Sukarela'
  },
  {
    id: '3',
    date: '15 Nov 2025',
    time: '09:00 WIB',
    title: 'Ruko 3 Lantai, Tangerang',
    location: 'Tangerang Selatan',
    type: 'Lelang Eksekusi Hak Tanggungan'
  },
  {
    id: '4',
    date: '20 Nov 2025',
    time: '11:00 WIB',
    title: 'Apartemen 2BR, Jakarta Selatan',
    location: 'Jakarta Selatan',
    type: 'Lelang Sukarela'
  },
  {
    id: '5',
    date: '25 Nov 2025',
    time: '13:00 WIB',
    title: 'Villa View Gunung, Bogor',
    location: 'Puncak, Bogor',
    type: 'Lelang Eksekusi'
  },
  {
    id: '6',
    date: '01 Des 2025',
    time: '10:00 WIB',
    title: 'Gudang Industri, Bekasi',
    location: 'Bekasi Timur',
    type: 'Lelang Sukarela'
  }
]

export default function NearestLelangPage() {
  return (
    <div className="min-h-screen">
      <section className="relative w-full min-h-screen">
        <Image 
          src="/images/lelang-terdekat/hero.svg"
          alt ="Lelang Terdekat background"
          priority
          fill
          sizes="100vw"
          className="object-cover"
        />
        
        
        {/* Header Section */}
        <FadeInUp delay={0}>
          <div className="text-start mt-12 md:mt-24 px-6 md:px-12 lg:px-24">
            <h1 className="font-manrope font-bold text-4xl md:text-5xl text-primary-600 mb-4">
              Jadwal Lelang Terdekat
            </h1>
            <p className="font-manrope text-neutral-700 text-lg md:text-xl leading-relaxed max-w-3xl mx-auto">
              Properti impian Anda 
            </p>
          </div>
        </FadeInUp>
      </section>
    </div>
  )
}